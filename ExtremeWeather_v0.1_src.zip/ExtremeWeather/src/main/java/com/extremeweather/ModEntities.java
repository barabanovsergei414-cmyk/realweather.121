package com.extremeweather;

import com.extremeweather.entity.HailStone;
import com.extremeweather.entity.VortexEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, ExtremeWeather.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<HailStone>> HAIL =
            ENTITY_TYPES.register("hail_stone", () -> EntityType.Builder.<HailStone>of(HailStone::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f).clientTrackingRange(4).updateInterval(10).build("hail_stone"));

    public static final DeferredHolder<EntityType<?>, EntityType<VortexEntity>> VORTEX =
            ENTITY_TYPES.register("vortex", () -> EntityType.Builder.<VortexEntity>of(VortexEntity::new, MobCategory.MISC)
                    .sized(2.0f, 4.0f).clientTrackingRange(10).updateInterval(2).fireImmune().noSave().build("vortex"));

    private ModEntities() {}
}
