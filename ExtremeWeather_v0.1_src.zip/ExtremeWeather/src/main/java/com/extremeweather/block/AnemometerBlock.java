package com.extremeweather.block;

import com.extremeweather.WindSystem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

/** Анемометр: показывает скорость и направление ветра (ПКМ) и выдаёт редстоун-сигнал 0..15 по скорости ветра. */
public class AnemometerBlock extends Block {
    public static final IntegerProperty POWER = BlockStateProperties.POWER;

    public AnemometerBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(POWER, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWER);
    }

    @Override
    protected boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
        return state.getValue(POWER);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
        if (!level.isClientSide) level.scheduleTick(pos, this, 20);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        double speed = WindSystem.speed(level);
        // под крышей ветра нет
        boolean open = level.canSeeSky(pos.above());
        int p = open ? (int) Math.min(15, Math.round(speed * 0.7)) : 0;
        if (p != state.getValue(POWER)) {
            level.setBlock(pos, state.setValue(POWER, p), Block.UPDATE_ALL);
        }
        level.scheduleTick(pos, this, 20);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide) {
            double speed = WindSystem.speed(level);
            String text = String.format("Ветер: %.1f м/с (%.0f км/ч), на %s", speed, speed * 3.6, WindSystem.compass(level));
            player.displayClientMessage(Component.literal(text), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
