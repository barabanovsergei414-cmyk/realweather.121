package com.extremeweather;

import com.extremeweather.command.WeatherCommands;
import com.extremeweather.event.WeatherEvents;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(ExtremeWeather.MODID)
public class ExtremeWeather {
    public static final String MODID = "extremeweather";

    public ExtremeWeather(IEventBus modBus, ModContainer container) {
        ModEntities.ENTITY_TYPES.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.ITEMS.register(modBus);
        modBus.addListener(this::addCreative);
        container.registerConfig(ModConfig.Type.COMMON, WeatherConfig.SPEC);
        NeoForge.EVENT_BUS.register(new WeatherEvents());
        NeoForge.EVENT_BUS.register(new WeatherCommands());
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(ModBlocks.ANEMOMETER_ITEM.get());
        }
    }
}
