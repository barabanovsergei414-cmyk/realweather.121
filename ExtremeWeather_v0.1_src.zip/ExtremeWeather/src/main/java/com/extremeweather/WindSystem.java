package com.extremeweather;

import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Ветер. Считается только по времени мира и погоде, поэтому на сервере и клиенте одинаковый и сеть не нужна.
 * Скорость в "м/с": 3..9 в ясную погоду, до ~20+ в грозу.
 */
public final class WindSystem {

    public static double speed(Level level) {
        double t = level.getGameTime();
        double base = 4.0 + 3.0 * Math.sin(t / 2400.0) + 2.0 * Math.sin(t / 911.0 + 1.7);
        base += 3.0 * level.getRainLevel(1.0f) + 9.0 * level.getThunderLevel(1.0f);
        return Math.max(0.0, base * WeatherConfig.WIND_SCALE.get());
    }

    /** Направление, КУДА дует ветер (радианы). 0 = на восток (+X), PI/2 = на юг (+Z). */
    public static double direction(Level level) {
        double t = level.getGameTime();
        return Math.toRadians(40.0 + 60.0 * Math.sin(t / 7200.0) + 25.0 * Math.sin(t / 1733.0));
    }

    /** Единичный вектор направления ветра (горизонтальный). */
    public static Vec3 unit(Level level) {
        double a = direction(level);
        return new Vec3(Math.cos(a), 0.0, Math.sin(a));
    }

    /** Вектор ветра в блоках/тик (для сноса частиц, града). */
    public static Vec3 vector(Level level) {
        return unit(level).scale(speed(level) * 0.02);
    }

    public static String compass(Level level) {
        double deg = (Math.toDegrees(direction(level)) % 360 + 360) % 360;   // куда дует
        // метеорологическое направление - откуда дует; 0 = восток, 90 = юг -> N=270
        String[] names = {"E", "SE", "S", "SW", "W", "NW", "N", "NE"};
        return names[(int) Math.round(deg / 45.0) % 8];
    }

    private WindSystem() {}
}
