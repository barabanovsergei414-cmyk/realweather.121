package com.extremeweather.command;

import com.extremeweather.ModEntities;
import com.extremeweather.WindSystem;
import com.extremeweather.entity.VortexEntity;
import com.extremeweather.entity.VortexKind;
import com.extremeweather.event.WeatherEvents;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.Arrays;

/**
 * /ew wind                       - ветер сейчас
 * /ew vortex <вид>               - создать вихрь перед собой (dust_devil, snow_devil, fire_whirl, landspout, waterspout)
 * /ew hail [штук]                - сбросить град над собой
 */
public class WeatherCommands {

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ew")
                .then(Commands.literal("wind").executes(c -> wind(c.getSource())))
                .then(Commands.literal("vortex").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("kind", StringArgumentType.word())
                                .suggests((ctx, b) -> {
                                    Arrays.stream(VortexKind.values()).forEach(k -> b.suggest(k.name().toLowerCase()));
                                    return b.buildFuture();
                                })
                                .executes(c -> vortex(c.getSource(), StringArgumentType.getString(c, "kind")))))
                .then(Commands.literal("hail").requires(s -> s.hasPermission(2))
                        .executes(c -> hail(c.getSource(), 40))
                        .then(Commands.argument("count", IntegerArgumentType.integer(1, 400))
                                .executes(c -> hail(c.getSource(), IntegerArgumentType.getInteger(c, "count"))))));
    }

    private int wind(CommandSourceStack src) {
        ServerLevel level = src.getLevel();
        double s = WindSystem.speed(level);
        src.sendSuccess(() -> Component.literal(String.format("Wind: %.1f m/s (%.0f km/h), blowing toward %s", s, s * 3.6, WindSystem.compass(level))), false);
        return 1;
    }

    private int vortex(CommandSourceStack src, String name) {
        VortexKind kind;
        try {
            kind = VortexKind.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            src.sendFailure(Component.literal("Unknown kind: " + name));
            return 0;
        }
        ServerLevel level = src.getLevel();
        Vec3 p = src.getPosition();
        Vec3 look = src.getRotation() != null ? Vec3.directionFromRotation(src.getRotation()) : Vec3.ZERO;
        VortexEntity v = new VortexEntity(ModEntities.VORTEX.get(), level);
        v.setPos(p.x + look.x * 12, p.y, p.z + look.z * 12);
        v.setKind(kind);
        level.addFreshEntity(v);
        src.sendSuccess(() -> Component.literal("Spawned " + kind.name().toLowerCase()), true);
        return 1;
    }

    private int hail(CommandSourceStack src, int count) {
        ServerLevel level = src.getLevel();
        Vec3 p = src.getPosition();
        for (int i = 0; i < count; i++) {
            WeatherEvents.spawnHailStone(level,
                    p.x + (level.random.nextDouble() - 0.5) * 20, p.y + 25 + level.random.nextInt(10),
                    p.z + (level.random.nextDouble() - 0.5) * 20, level.random.nextFloat());
        }
        src.sendSuccess(() -> Component.literal("Hail: " + count), true);
        return count;
    }
}
