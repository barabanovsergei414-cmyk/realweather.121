package com.extremeweather;

import com.extremeweather.block.AnemometerBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, ExtremeWeather.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, ExtremeWeather.MODID);

    public static final DeferredHolder<Block, AnemometerBlock> ANEMOMETER = BLOCKS.register("anemometer",
            () -> new AnemometerBlock(BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.METAL).noOcclusion()));

    public static final DeferredHolder<Item, BlockItem> ANEMOMETER_ITEM = ITEMS.register("anemometer",
            () -> new BlockItem(ANEMOMETER.get(), new Item.Properties()));

    private ModBlocks() {}
}
