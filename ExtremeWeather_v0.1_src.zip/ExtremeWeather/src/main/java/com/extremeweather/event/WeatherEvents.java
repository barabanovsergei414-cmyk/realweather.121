package com.extremeweather.event;

import com.extremeweather.ModEntities;
import com.extremeweather.WeatherConfig;
import com.extremeweather.WindSystem;
import com.extremeweather.entity.HailStone;
import com.extremeweather.entity.VortexEntity;
import com.extremeweather.entity.VortexKind;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

import java.util.List;
import net.minecraft.core.Holder;

/** Серверная логика: град в грозу и появление вихрей рядом с игроками. */
public class WeatherEvents {

    @SubscribeEvent
    public void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (level.dimension() != net.minecraft.world.level.Level.OVERWORLD) return;
        long t = level.getGameTime();
        if (WeatherConfig.HAIL.get() && t % 5 == 0 && hailActive(level, t)) spawnHail(level);
        if (WeatherConfig.VORTICES.get() && t % 100 == 0) trySpawnVortices(level);
    }

    /** Град идёт не всю грозу, а "ячейками": примерно треть времени. */
    public static boolean hailActive(ServerLevel level, long t) {
        return level.isThundering() && (Math.sin(t / 900.0) + Math.sin(t / 523.0 + 1.3)) > 0.3;
    }

    private void spawnHail(ServerLevel level) {
        int rate = WeatherConfig.HAIL_RATE.get();
        for (ServerPlayer p : level.players()) {
            for (int i = 0; i < rate; i++) {
                double x = p.getX() + (level.random.nextDouble() - 0.5) * 56.0;
                double z = p.getZ() + (level.random.nextDouble() - 0.5) * 56.0;
                BlockPos col = new BlockPos(Mth.floor(x), 0, Mth.floor(z));
                if (!level.hasChunkAt(col)) continue;
                if (!level.getBiome(col).value().hasPrecipitation()) continue;
                int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, col.getX(), col.getZ());
                double y = Math.min(top + 28 + level.random.nextInt(14), level.getMaxBuildHeight() - 2);
                spawnHailStone(level, x, y, z, level.random.nextFloat());
            }
        }
    }

    public static void spawnHailStone(ServerLevel level, double x, double y, double z, float sizeRoll) {
        HailStone h = new HailStone(ModEntities.HAIL.get(), level);
        h.setPos(x, y, z);
        h.setHailSize(sizeRoll < 0.6f ? 1 : (sizeRoll < 0.9f ? 2 : 3));
        Vec3 w = WindSystem.vector(level);
        h.setDeltaMovement(w.x * 0.4, -1.3, w.z * 0.4);
        level.addFreshEntity(h);
    }

    // ------------------------------------------------------------------ vortices

    private void trySpawnVortices(ServerLevel level) {
        for (ServerPlayer p : level.players()) {
            AABB near = new AABB(p.getX() - 128, p.getY() - 64, p.getZ() - 128, p.getX() + 128, p.getY() + 128, p.getZ() + 128);
            List<VortexEntity> existing = level.getEntitiesOfClass(VortexEntity.class, near);
            if (existing.size() >= 3) continue;

            double ang = level.random.nextDouble() * Math.PI * 2;
            double dist = 30 + level.random.nextDouble() * 60;
            int x = Mth.floor(p.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunk(x >> 4, z >> 4)) continue;
            BlockPos surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
            VortexKind kind = chooseKind(level, surface);

            // огненный вихрь - только рядом с настоящим пожаром
            VortexKind fire = findFire(level, p);
            Vec3 pos = new Vec3(surface.getX() + 0.5, surface.getY(), surface.getZ() + 0.5);
            if (fire != null && WeatherConfig.FIRE_WHIRLS.get()) {
                kind = fire;
                pos = lastFirePos;
            }
            if (kind == null) continue;
            if (level.random.nextDouble() > 0.25 * WeatherConfig.VORTEX_CHANCE.get() * chanceFor(kind)) continue;
            VortexEntity v = new VortexEntity(ModEntities.VORTEX.get(), level);
            v.setPos(pos.x, pos.y, pos.z);
            v.setKind(kind);
            level.addFreshEntity(v);
        }
    }

    private static double chanceFor(VortexKind kind) {
        return switch (kind) {
            case DUST_DEVIL, SNOW_DEVIL -> 1.0;
            case FIRE_WHIRL -> 3.0;
            case LANDSPOUT -> 0.8;
            case WATERSPOUT -> 0.9;
        };
    }

    private VortexKind chooseKind(ServerLevel level, BlockPos surface) {
        Holder<Biome> biome = level.getBiome(surface);
        boolean raining = level.isRaining();
        boolean thunder = level.isThundering();
        boolean over = level.getFluidState(surface.below()).is(FluidTags.WATER);

        if (over) {
            if (!WeatherConfig.WATERSPOUTS.get()) return null;
            return (thunder || raining) ? VortexKind.WATERSPOUT : (level.random.nextInt(3) == 0 ? VortexKind.WATERSPOUT : null);
        }
        if (thunder && WeatherConfig.LANDSPOUTS.get()) return VortexKind.LANDSPOUT;
        if (raining) return null;
        if (!level.isDay()) return null;
        if ((biome.is(Biomes.DESERT) || biome.is(BiomeTags.IS_BADLANDS)) && WeatherConfig.DUST_DEVILS.get()) return VortexKind.DUST_DEVIL;
        if (biome.value().coldEnoughToSnow(surface) && WeatherConfig.SNOW_DEVILS.get()) return VortexKind.SNOW_DEVIL;
        return null;
    }

    private Vec3 lastFirePos = Vec3.ZERO;

    private VortexKind findFire(ServerLevel level, ServerPlayer p) {
        double ang = level.random.nextDouble() * Math.PI * 2;
        double dist = 10 + level.random.nextDouble() * 40;
        int cx = Mth.floor(p.getX() + Math.cos(ang) * dist);
        int cz = Mth.floor(p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunk(cx >> 4, cz >> 4)) return null;
        int cy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz);
        AABB box = new AABB(cx - 4, cy - 3, cz - 4, cx + 5, cy + 4, cz + 5);
        long fires = level.getBlockStatesIfLoaded(box).filter(s -> s.is(BlockTags.FIRE)).count();
        if (fires < 10) return null;
        lastFirePos = new Vec3(cx + 0.5, cy, cz + 0.5);
        return VortexKind.FIRE_WHIRL;
    }
}
