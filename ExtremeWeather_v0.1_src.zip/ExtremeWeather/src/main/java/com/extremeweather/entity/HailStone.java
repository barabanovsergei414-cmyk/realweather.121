package com.extremeweather.entity;

import com.extremeweather.WeatherConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.neoforge.common.Tags;

/** Градина. Размер 1 (горох) .. 3 (крупный град). Шлем снижает урон, крупный град бьёт стекло, листву и посевы. */
public class HailStone extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Integer> SIZE =
            SynchedEntityData.defineId(HailStone.class, EntityDataSerializers.INT);

    public HailStone(EntityType<? extends HailStone> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SIZE, 1);
    }

    public int getHailSize() { return entityData.get(SIZE); }
    public void setHailSize(int s) { entityData.set(SIZE, Math.max(1, Math.min(3, s))); }

    @Override
    protected Item getDefaultItem() {
        return Items.SNOWBALL;
    }

    private float damage() {
        return switch (getHailSize()) {
            case 1 -> 1.5f;
            case 2 -> 4.0f;
            default -> 8.0f;
        };
    }

    @Override
    public void tick() {
        super.tick();
        if (tickCount > 400) discard();   // на всякий случай
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity target = result.getEntity();
        float dmg = damage();
        if (target instanceof LivingEntity living) {
            ItemStack helmet = living.getItemBySlot(EquipmentSlot.HEAD);
            if (!helmet.isEmpty()) {
                dmg *= 0.35f;
                helmet.hurtAndBreak(1, living, EquipmentSlot.HEAD);
            }
        }
        target.hurt(level().damageSources().thrown(this, getOwner()), dmg);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (level().isClientSide) return;
        BlockPos pos = result.getBlockPos();
        BlockState state = level().getBlockState(pos);
        int size = getHailSize();
        if (WeatherConfig.HAIL_BREAKS_BLOCKS.get()) {
            if (state.is(BlockTags.CROPS) && size >= 2) {
                level().destroyBlock(pos, true);
            } else if (size >= 2 && state.is(BlockTags.LEAVES)) {
                level().destroyBlock(pos, false);
            } else if (size >= 3 && (state.is(Tags.Blocks.GLASS_BLOCKS) || state.is(Tags.Blocks.GLASS_PANES) || state.is(BlockTags.ICE))) {
                level().destroyBlock(pos, false);
            }
        }
        level().playSound(null, pos, SoundEvents.GLASS_HIT, SoundSource.WEATHER, 0.4f + 0.2f * size, 1.4f);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) discard();
    }
}
