package com.extremeweather.entity;

import com.extremeweather.WeatherConfig;
import com.extremeweather.WindSystem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.List;

/**
 * Малый вихрь: пыльный/снежный дьявол, огненный вихрь, ландспаут, водяной смерч.
 * Дрейфует по ветру, держится на поверхности, закручивает и поднимает сущности. Частицы рисуются на клиенте.
 */
public class VortexEntity extends Entity {
    private static final EntityDataAccessor<Integer> KIND =
            SynchedEntityData.defineId(VortexEntity.class, EntityDataSerializers.INT);

    private int life = 1800;
    private double wanderAngle;

    public VortexEntity(EntityType<? extends VortexEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.wanderAngle = Math.random() * Math.PI * 2;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(KIND, VortexKind.DUST_DEVIL.ordinal());
    }

    public VortexKind getKind() { return VortexKind.byId(entityData.get(KIND)); }

    public void setKind(VortexKind kind) {
        entityData.set(KIND, kind.ordinal());
        this.life = kind.minLife + random.nextInt(kind.maxLife - kind.minLife + 1);
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }

    @Override
    public AABB getBoundingBoxForCulling() {
        VortexKind k = getKind();
        return new AABB(getX() - k.radius * 3, getY() - 1, getZ() - k.radius * 3, getX() + k.radius * 3, getY() + k.height + 2, getZ() + k.radius * 3);
    }

    @Override
    public void tick() {
        VortexKind kind = getKind();
        if (level().isClientSide) {
            spawnParticles(kind);
            return;
        }
        tickCount++;
        // жизнь; водяной смерч над сушей быстро затухает
        life -= 1;
        if (kind == VortexKind.WATERSPOUT && !overWater()) life -= 20;
        if (life <= 0 || level().getNearestPlayer(this, 180.0) == null) {
            discard();
            return;
        }
        drift();
        if (tickCount % 2 == 0) affectEntities(kind);
        if (kind == VortexKind.FIRE_WHIRL && tickCount % 10 == 0) burnBlocks();
        if (kind == VortexKind.LANDSPOUT && tickCount % 20 == 0) tearLeaves();
    }

    private boolean overWater() {
        BlockPos p = BlockPos.containing(getX(), getY() - 0.5, getZ());
        return level().getFluidState(p).is(net.minecraft.tags.FluidTags.WATER);
    }

    private void drift() {
        Vec3 wind = WindSystem.vector(level());
        wanderAngle += (random.nextDouble() - 0.5) * 0.12;
        double wx = Math.cos(wanderAngle) * 0.03;
        double wz = Math.sin(wanderAngle) * 0.03;
        double nx = getX() + wind.x * 0.5 + wx;
        double nz = getZ() + wind.z * 0.5 + wz;
        int bx = Mth_floor(nx);
        int bz = Mth_floor(nz);
        if (!level().hasChunk(bx >> 4, bz >> 4)) return;
        int y = level().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
        setPos(nx, y, nz);
    }

    private static int Mth_floor(double v) { return (int) Math.floor(v); }

    private void affectEntities(VortexKind kind) {
        double r = kind.radius * 2.2;
        AABB box = new AABB(getX() - r, getY() - 1, getZ() - r, getX() + r, getY() + kind.height, getZ() + r);
        List<Entity> list = level().getEntities(this, box, e -> !(e instanceof VortexEntity) && e.isAlive());
        for (Entity e : list) {
            if (e instanceof Player p && (p.isSpectator() || p.getAbilities().flying)) continue;
            Vec3 d = new Vec3(e.getX() - getX(), 0, e.getZ() - getZ());
            double dist = d.length();
            if (dist > r || dist < 1.0e-3) continue;
            double str = 1.0 - dist / r;
            Vec3 tangent = new Vec3(-d.z, 0, d.x).scale(1.0 / dist);
            Vec3 inward = d.scale(-1.0 / dist);
            double lift = (dist < r * 0.6) ? 0.05 * kind.power * str : 0.0;
            Vec3 push = tangent.scale(0.06 * kind.power * str)
                    .add(inward.scale(0.035 * kind.power * str))
                    .add(0, lift, 0);
            Vec3 m = e.getDeltaMovement().add(push);
            if (m.y > 0.45) m = new Vec3(m.x, 0.45, m.z);
            e.setDeltaMovement(m);
            e.hurtMarked = true;
            if (lift > 0) e.fallDistance = 0;

            if (tickCount % 20 == 0 && str > 0.4 && kind.damage > 0) {
                e.hurt(level().damageSources().generic(), kind.damage);
            }
            if (e instanceof LivingEntity le) {
                switch (kind) {
                    case DUST_DEVIL -> le.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, false, false));
                    case SNOW_DEVIL -> {
                        le.setTicksFrozen(Math.min(le.getTicksRequiredToFreeze() + 40, le.getTicksFrozen() + 6));
                        le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, false));
                    }
                    case FIRE_WHIRL -> le.setRemainingFireTicks(Math.max(le.getRemainingFireTicks(), 100));
                    default -> { }
                }
            }
        }
    }

    private void burnBlocks() {
        int x = Mth_floor(getX()) + random.nextInt(7) - 3;
        int z = Mth_floor(getZ()) + random.nextInt(7) - 3;
        int y = Mth_floor(getY()) + random.nextInt(4);
        BlockPos pos = new BlockPos(x, y, z);
        if (!level().hasChunkAt(pos)) return;
        BlockState st = level().getBlockState(pos);

        if (WeatherConfig.BURNT_COMPAT.get() && !st.isAir() && st.ignitedByLava()) {
            ResourceLocation id = BuiltInRegistries.BLOCK.getKey(st.getBlock());
            ResourceLocation burnt = ResourceLocation.fromNamespaceAndPath("burnt", "burnt_" + id.getPath());
            var opt = BuiltInRegistries.BLOCK.getOptional(burnt);
            if (opt.isPresent()) {
                level().setBlock(pos, opt.get().defaultBlockState(), Block.UPDATE_ALL);
                return;
            }
        }
        if (st.isAir() && Blocks.FIRE.defaultBlockState().canSurvive(level(), pos)) {
            level().setBlock(pos, Blocks.FIRE.defaultBlockState(), Block.UPDATE_ALL);
        }
    }

    private void tearLeaves() {
        int x = Mth_floor(getX()) + random.nextInt(9) - 4;
        int z = Mth_floor(getZ()) + random.nextInt(9) - 4;
        int y = Mth_floor(getY()) + random.nextInt(8);
        BlockPos pos = new BlockPos(x, y, z);
        if (level().hasChunkAt(pos) && level().getBlockState(pos).is(BlockTags.LEAVES)) {
            level().destroyBlock(pos, false);
        }
    }

    // ---------------- client ----------------

    private void spawnParticles(VortexKind kind) {
        double h = kind.height;
        double age = tickCount++;
        for (int i = 0; i < 10; i++) {
            double f = random.nextDouble();                       // доля высоты
            double rad = kind.radius * (0.25 + 0.85 * f) * (0.6 + 0.4 * random.nextDouble());
            double ang = age * 0.30 * (1.2 - 0.5 * f) + random.nextDouble() * Math.PI * 2;
            double px = getX() + Math.cos(ang) * rad;
            double pz = getZ() + Math.sin(ang) * rad;
            double py = getY() + f * h;
            double vx = -Math.sin(ang) * 0.22;
            double vz = Math.cos(ang) * 0.22;
            level().addParticle(particleFor(kind), px, py, pz, vx, 0.08, vz);
        }
        if (kind == VortexKind.FIRE_WHIRL && random.nextInt(2) == 0) {
            level().addParticle(ParticleTypes.LARGE_SMOKE, getX() + (random.nextDouble() - 0.5) * 2, getY() + h * random.nextDouble(), getZ() + (random.nextDouble() - 0.5) * 2, 0, 0.1, 0);
        }
        if (kind == VortexKind.WATERSPOUT) {
            level().addParticle(ParticleTypes.SPLASH, getX() + (random.nextDouble() - 0.5) * 5, getY() + 0.2, getZ() + (random.nextDouble() - 0.5) * 5, 0, 0.3, 0);
        }
    }

    private ParticleOptions particleFor(VortexKind kind) {
        return switch (kind) {
            case DUST_DEVIL -> new DustParticleOptions(new Vector3f(0.78f, 0.66f, 0.45f), 1.6f);
            case SNOW_DEVIL -> ParticleTypes.SNOWFLAKE;
            case FIRE_WHIRL -> random.nextInt(3) == 0 ? ParticleTypes.FLAME : ParticleTypes.SMOKE;
            case LANDSPOUT -> random.nextInt(2) == 0 ? new DustParticleOptions(new Vector3f(0.45f, 0.45f, 0.48f), 1.8f) : ParticleTypes.CLOUD;
            case WATERSPOUT -> random.nextInt(2) == 0 ? ParticleTypes.CLOUD : ParticleTypes.FALLING_WATER;
        };
    }
}
