package com.extremeweather.entity;

/** Виды вихрей. radius - радиус действия (блоки), height - высота столба, power - сила закручивания, damage - урон раз в секунду. */
public enum VortexKind {
    DUST_DEVIL(2.2, 11, 0.7, 0.0f, 1200, 2400),
    SNOW_DEVIL(2.4, 12, 0.7, 0.0f, 1200, 2400),
    FIRE_WHIRL(2.6, 16, 1.0, 1.0f, 900, 1800),
    LANDSPOUT(3.0, 24, 1.3, 2.0f, 1200, 3000),
    WATERSPOUT(3.5, 30, 1.2, 1.0f, 1800, 4800);

    public final double radius;
    public final int height;
    public final double power;
    public final float damage;
    public final int minLife;
    public final int maxLife;

    VortexKind(double radius, int height, double power, float damage, int minLife, int maxLife) {
        this.radius = radius;
        this.height = height;
        this.power = power;
        this.damage = damage;
        this.minLife = minLife;
        this.maxLife = maxLife;
    }

    public static VortexKind byId(int id) {
        VortexKind[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, id))];
    }
}
