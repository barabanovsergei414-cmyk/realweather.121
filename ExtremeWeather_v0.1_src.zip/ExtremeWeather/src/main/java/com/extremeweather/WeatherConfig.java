package com.extremeweather;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class WeatherConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue WIND_ON_PLAYER;
    public static final ModConfigSpec.DoubleValue WIND_FORCE;
    public static final ModConfigSpec.DoubleValue WIND_SCALE;
    public static final ModConfigSpec.BooleanValue HAIL;
    public static final ModConfigSpec.IntValue HAIL_RATE;
    public static final ModConfigSpec.BooleanValue HAIL_BREAKS_BLOCKS;
    public static final ModConfigSpec.BooleanValue VORTICES;
    public static final ModConfigSpec.DoubleValue VORTEX_CHANCE;
    public static final ModConfigSpec.BooleanValue DUST_DEVILS;
    public static final ModConfigSpec.BooleanValue SNOW_DEVILS;
    public static final ModConfigSpec.BooleanValue FIRE_WHIRLS;
    public static final ModConfigSpec.BooleanValue LANDSPOUTS;
    public static final ModConfigSpec.BooleanValue WATERSPOUTS;
    public static final ModConfigSpec.BooleanValue BURNT_COMPAT;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.push("wind");
        WIND_ON_PLAYER = b.comment("Wind pushes players outdoors (slows you against the wind, speeds you with it)").define("windOnPlayer", true);
        WIND_FORCE = b.comment("Strength of the push on the player").defineInRange("windForce", 1.0, 0.0, 5.0);
        WIND_SCALE = b.comment("Overall wind speed multiplier").defineInRange("windScale", 1.0, 0.0, 3.0);
        b.pop();
        b.push("hail");
        HAIL = b.comment("Hail falls during thunderstorms").define("hail", true);
        HAIL_RATE = b.comment("Hailstones per player every 5 ticks while hailing").defineInRange("hailRate", 3, 1, 30);
        HAIL_BREAKS_BLOCKS = b.comment("Large hail breaks glass, leaves, crops and ice").define("hailBreaksBlocks", true);
        b.pop();
        b.push("vortices");
        VORTICES = b.comment("Dust devils, snow devils, fire whirls, landspouts and waterspouts").define("vortices", true);
        VORTEX_CHANCE = b.comment("Spawn chance multiplier").defineInRange("vortexChance", 1.0, 0.0, 5.0);
        DUST_DEVILS = b.define("dustDevils", true);
        SNOW_DEVILS = b.define("snowDevils", true);
        FIRE_WHIRLS = b.define("fireWhirls", true);
        LANDSPOUTS = b.define("landspouts", true);
        WATERSPOUTS = b.define("waterspouts", true);
        BURNT_COMPAT = b.comment("Best effort: fire whirls turn blocks into 'burnt:burnt_<name>' blocks when the Burnt mod provides them").define("burntCompat", true);
        b.pop();
        SPEC = b.build();
    }

    private WeatherConfig() {}
}
