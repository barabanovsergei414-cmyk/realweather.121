package com.extremeweather.client;

import com.extremeweather.ExtremeWeather;
import com.extremeweather.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = ExtremeWeather.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.HAIL.get(), ctx -> new ThrownItemRenderer<>(ctx, 0.8f, true));
        event.registerEntityRenderer(ModEntities.VORTEX.get(), NoopRenderer::new);
    }
}
