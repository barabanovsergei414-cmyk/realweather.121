package com.extremeweather.client;

import com.extremeweather.ExtremeWeather;
import com.extremeweather.WeatherConfig;
import com.extremeweather.WindSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Ветер на игрока (на клиенте, потому что движением игрока управляет клиент): идти против ветра тяжелее,
 * по ветру - легче. Не действует под крышей, в воде, в полёте и в креативном полёте.
 */
@EventBusSubscriber(modid = ExtremeWeather.MODID, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (!WeatherConfig.WIND_ON_PLAYER.get()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.isPaused()) return;
        if (p.getAbilities().flying || p.isFallFlying() || p.isInWater() || p.isPassenger() || p.isSpectator()) return;
        if (!mc.level.canSeeSky(p.blockPosition().above())) return;   // под крышей ветра нет

        double speed = WindSystem.speed(mc.level);
        if (speed < 6.0) return;                                       // лёгкий ветер не толкает
        double push = (speed - 6.0) * 0.0012 * WeatherConfig.WIND_FORCE.get();
        Vec3 dir = WindSystem.unit(mc.level);
        if (!p.onGround()) push *= 0.5;
        p.setDeltaMovement(p.getDeltaMovement().add(dir.x * push, 0, dir.z * push));
    }
}
